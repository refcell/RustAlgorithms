# Test Cargo Publish

This is a test project to publish to [crates.io](https://crates.io)
